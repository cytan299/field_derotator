/**************
Feb. 2015 C.Y. Tan   - cytan299@yahoo.com
creative commons license 3.0: Attribution-ShareAlike CC BY-SA
This software is furnished "as is", without technical support, and with no 
warranty, express or implied, as to its usefulness for any purpose.

Thread Safe: No
Extendable: Yes

Driver for the ADAFRUIT LCD Shield buttons
***/
#ifndef KEYADAFRUITSTREAM_H
#define KEYADAFRUITSTREAM_H

struct keyMap {
  uint8_t pin;
  char code;
};

//emulate a stream keyboard, this is not using interrupts as a good driver should do
// AND is not using a buffer either!
template <int N>
class keyLook:public Stream {
public:
  keyMap* keys;
  Adafruit_RGBLCDShield* lcd;  
  keyLook<N>(keyMap k[], Adafruit_RGBLCDShield* plcd):keys(k) {lcd = plcd;}
  int available(void) {
    return N;
  }
  int peek(void) {
    uint8_t buttons = lcd->readButtons();    
    
    for(int n=0;n<N;n++) {
      uint8_t pin=keys[n].pin;
      if (pin & buttons) {
	return keys[n].code;
      }
    }
    return -1;
  }
  int read() {
    
    uint8_t buttons = lcd->readButtons();    
    
    for(int n=0;n<N;n++) {
      int8_t pin=keys[n].pin;
      if (pin & buttons) {
	return keys[n].code;
      }
    }    

    return -1;
  }
  void flush() {}
  size_t write(uint8_t v) {return 0;}
};


#endif
